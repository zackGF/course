import os

basedir = os.path.abspath(os.path.dirname(__file__))
dev_data = "sqlite:///"+os.path.join(basedir,'dev.sqlite')
class Config():
    SECRET_KEY="sdfew;/ewf"
    SQLALCHEMY_TRACK_MODIFICATIONS = True

class DevelopConfig(Config):
    SQLALCHEMY_DATABASE_URI = dev_data


config = {
    'default':DevelopConfig
}




