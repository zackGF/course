from App import db
from passlib.apps import custom_app_context
from datetime import datetime


class Course(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    title = db.Column(db.String(64))
    tch = db.Column(db.String(64))
    school = db.Column(db.String(64))
    image = db.Column(db.Text)
    url_href = db.Column(db.Text)

    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'tch': self.tch,
            'school': self.school,
            'image': self.image,
            'url_href': self.url_href
        }


class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    stunum = db.Column(db.Integer, unique=True)
    stupwd = db.Column(db.String(128))
    created_at = db.Column(db.DateTime, default=datetime.now)

    def hash_password(self, password):
        self.stupwd = custom_app_context.encrypt(password)

    def verify_password(self, password):
        return custom_app_context.verify(password, self.stupwd)


class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    stunum = db.Column(db.Integer)
    text = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'name': self.stunum,
            'text': self.text,
            'created_at': self.created_at.strftime('%Y-%m-%dT%H:%M:%SZ')}
