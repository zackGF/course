from flask import Blueprint, jsonify

from App.models import Course

course = Blueprint('course',__name__)

@course.route("/")
def get_course():
    return jsonify("hello")

@course.route("/list")
def course_list():
    course_obj = Course.query.all()
    return jsonify([course.to_dict() for course in course_obj])