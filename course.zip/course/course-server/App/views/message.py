from flask import Blueprint, jsonify, request

from App import db
from App.models import Message, Student

message = Blueprint('message', __name__)


@message.route('/list')
def get_list():
    messages = Message.query.order_by(Message.created_at.desc()).all()
    return jsonify([message.to_dict() for message in messages])


@message.route('/add_msg', methods=["POST"])
def add_msg():
    stunum = request.json['name']
    text = request.json['text']
    stu_obj = Student.query.filter_by(stunum=stunum).first()
    if stu_obj:
        msg_obj = Message(stunum=stunum, text=text)
        db.session.add(msg_obj)
        db.session.commit()
        return jsonify(ok=True)
    else:
        return jsonify({"code": 0, "msg": "发生未知错误", "result": "Number is modified"})
