from flask import Blueprint, request, jsonify, g
from itsdangerous import TimedJSONWebSignatureSerializer as Serializer, SignatureExpired, BadSignature
from App import db
from App.models import Student
from flask_httpauth import HTTPTokenAuth

auth = HTTPTokenAuth(scheme='Bearer')
student = Blueprint('student', __name__)
s = Serializer('student', expires_in=600)


@auth.verify_token
def verify_token(token):
    try:
        data = s.loads(token)
    except SignatureExpired:
        return False
    except BadSignature:
        return False
    except:
        return False
    if 'stunum' in data:
        g.stunum = data['stunum']
        return True
    return False


@auth.error_handler
def err():
    return jsonify({"code": 0, "msg": "Unauthorized Access", "result": "未知错误"})


@student.route('/info')
@auth.login_required
def stuinfo():
    stunum = g.stunum
    return jsonify({"code": 1,
                    "msg": "success",
                    "result": {"stunum": stunum}})


@student.route('/login', methods=["POST"])
def stuLogin():
    stunum = request.json['stunum']
    stupwd = request.json['stupwd']
    obj = Student.query.filter_by(stunum=stunum).first()
    if not obj:
        return jsonify({"code": 0, "msg": "学号密码错误"})
    if obj.verify_password(stupwd):
        token = s.dumps({'stunum': stunum}).decode('utf8')
        return jsonify({"code": 1, "msg": "登录成功", "stu_token": token})
    else:
        return jsonify({"code": 0, "msg": "学号或密码错误"})


@student.route('/register', methods=['POST'])
def stuRegister():
    stunum = request.json['stunum']
    stupwd = request.json['stupwd_1']
    if stunum is None or stupwd is None:
        return jsonify({"code": 0, "msg": "学号密码不能为空"})
    if Student.query.filter_by(stunum=stunum).first() is not None:
        return jsonify({"code": 0, "msg": "学号已存在"})
    student = Student(stunum=stunum)
    student.hash_password(stupwd)
    db.session.add(student)
    db.session.commit()
    return jsonify({"code": 1, "msg": "注册成功"})
