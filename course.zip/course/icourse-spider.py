"""
爱课程网站课程信息爬取
"""
import re

import requests


def get_icourse(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36'
    }
    icourse = requests.get(url=url, headers=headers)
    icourse.encoding = 'utf8'
    if icourse.status_code == 200:
        expression = '<img\sonerror=".*?"\ssrc="(.*?)".*?<a\sclass="icourse-desc-title"\shref="(.*?)".*?title="(.*?)"\starget="_blank">.*?title="(.*?)\s\D\s(.*?)">'
        results = re.findall(expression, icourse.text, re.S)
        for r in results:
            iImg = r[0]
            iLink = r[1]
            iTitle = r[2]
            iTeacher = r[3]
            iSchool = r[4]
            print(type(r))
            print(type(iSchool))
            print("课程名：" + iTitle, "||教师：" + iTeacher, "||学校：" + iSchool, "||课程链接：" + iLink, "||图片：" + iImg)
        with open('icourse.txt', 'a', encoding='utf8') as f:    # 将数据保存并且生成icourse.txt文件
            f.write(str(results))
            f.close()

if __name__ == '__main__':
    url = 'http://www.icourses.cn/mooc/'
    get_icourse(url)
