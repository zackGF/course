<template>
  <div id="app">
    <el-container>
      <el-header style="position: fixed; top: 0;z-index: 999;width: 100%;">
        <el-menu default-active="activeIndex" class="el-menu-demo navheader" mode="horizontal">
<!--          <el-menu-item index="1">-->
<!--            <router-link to="/index">首页</router-link>-->
<!--          </el-menu-item>-->
          <el-menu-item index="2">
            <router-link to="/">资源共享课</router-link>
          </el-menu-item>
          <el-menu-item index="3">
            <router-link to="/messages">留言板</router-link>
          </el-menu-item>
          <el-menu-item index="4">
            <router-link to="/me">我的</router-link>
          </el-menu-item>
        </el-menu>
      </el-header>
      <el-main style="margin-top: 60px">
        <router-view></router-view>
      </el-main>

    </el-container>
  </div>
</template>

<script>
  export default {
    name: 'App'
  }
</script>

<style>
  /*#app {*/
  /*  font-family: 'Avenir', Helvetica, Arial, sans-serif;*/
  /*  -webkit-font-smoothing: antialiased;*/
  /*  -moz-osx-font-smoothing: grayscale;*/
  /*  text-align: center;*/
  /*  color: #2c3e50;*/
  /*  margin-top: 60px;*/
  /*}*/
  .navheader {
    display: flex;
    flex-direction: row;
    justify-content: space-around;
  }
</style>
