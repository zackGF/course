import Vue from 'vue'
import Router from 'vue-router'
import HelloWorld from '@/components/HelloWorld'

// import CourseIndex from '@/views/CourseIndex'
import CourseShare from '@/views/CourseShare'
import CourseMessages from '@/views/CourseMessages'
import CourseMe from '@/views/CourseMe'

import StuLogin from '@/components/StuLogin'
import StuReg from '@/components/StuRegister'

Vue.use(Router)

export default new Router({
  mode: 'history',
  routes: [
    {
      path: '/hello',
      name: 'HelloWorld',
      component: HelloWorld
    },
    // {
    //   path: '/index',
    //   component: CourseIndex
    // },
    {
      path: '/',
      component: CourseShare
    },
    {
      path: '/messages',
      component: CourseMessages
    },
    {
      path: '/me',
      component: CourseMe,
      children: [
        {
          path: '/',
          name:'StuLogin',
          index : true,
          component: StuLogin
        },
        {
          path: 'stu_register',
          name:'StuReg',
          component: StuReg
        }
      ]
    }
  ]
})
