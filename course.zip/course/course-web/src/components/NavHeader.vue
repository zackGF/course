<template>
  <div class="navheader">
    <el-menu default-active="activeIndex" class="el-menu-demo" mode="horizontal">
      <el-menu-item index="1">首页</el-menu-item>
      <el-menu-item index="2">资源共享课</el-menu-item>
      <el-menu-item index="3">消息中心</el-menu-item>
      <el-menu-item index="4">我的</el-menu-item>
    </el-menu>
  </div>
</template>

<script>
  export default {
    name: "NavHeader"
  }
</script>

<style scoped>
  .navheader{
    display: flex;
    justify-content: space-around;
    flex-direction: row-reverse;
  }
</style>
