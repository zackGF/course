<template>
    
</template>

<script>
    export default {
        name: "StuInfo"
    }
</script>

<style scoped>

</style>
