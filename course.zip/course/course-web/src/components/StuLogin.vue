<template>
  <div>
    <div style="text-align: center">
      <h1>学生登录</h1>
    </div>

    <div>
      <el-input v-model="stunum" placeholder="请输入学号">
      </el-input>
    </div>

    <div style="margin-top: 10px">
      <el-input v-model="stupwd" placeholder="请输入密码" show-password>
      </el-input>
    </div>
    <div style="margin-top: 10px;text-align: center">
      <el-button type="success" @click="DoStuLogin">登录</el-button>
    </div>

  </div>

</template>

<script>
  import axiox from 'axios'
  import {mapMutations} from 'vuex'

  export default {
    name: "StuLogin",
    data() {
      return {
        stunum: '',
        stupwd: '',
        studentToken:''
      }
    },
    methods: {
      ...mapMutations(['changeLogin']),
      DoStuLogin() {
        // console.log("学号：" + this.stunum + "," + "密码：" + this.stupwd);
        let _this = this;
        axiox.post("http://127.0.0.1:5000/api/student/login",{
          stunum:this.stunum,
          stupwd:this.stupwd
        }).then(res=>{
          _this.studentToken = 'Bearer '+res.data.stu_token
          // console.log(this.studentToken);
          _this.changeLogin({Authorization:this.studentToken})
          this.$router.push('/')
          alert("登录成功")
        })
      }
    }
  }
</script>

<style scoped>

</style>
