<template>
  <div>
    <div style="text-align: center">
      <h1>学生注册</h1>
    </div>

    <span style="color: orange">{{waring_info}}</span>
    <div style="margin-top: 10px">
      <el-input v-model="stunum" placeholder="请输入学号">
      </el-input>
    </div>

    <div style="margin-top: 10px">
      <el-input v-model="stupwd_1" placeholder="请输入密码" show-password>
      </el-input>
    </div>
    <div style="margin-top: 10px">
      <el-input v-model="stupwd_2" placeholder="请确认密码" show-password>
      </el-input>
    </div>
    <div style="margin-top: 10px;text-align: center">
      <el-button type="primary" @click="DoStuReg">注册</el-button>
    </div>
  </div>
</template>

<script>
  import axios from 'axios'

  export default {
    name: "StuRegister",
    data() {
      return {
        waring_info: '',
        stunum: '',
        stupwd_1: '',
        stupwd_2: ''
      }
    },
    methods: {
      DoStuReg() {
        let stunum = this.stunum;
        let stupwd_1 = this.stupwd_1;
        let stupwd_2 = this.stupwd_2;
        if (stunum.length < 3 || stupwd_1.length < 3 || stupwd_2.length < 3) {
          this.waring_info = "所输入的内容长度不足"
          return;
        }
        if (stupwd_1 != stupwd_2) {
          this.waring_info = "两次密码不同"
          return;
        }
        // axios.post("http://127.0.0.1/api/student/register",{
        //   stunum:this.stunum,
        //   stupwd_1:this.stupwd_1
        // }).then(res=>{
        //   if (res.data.code = 1) {
        //     this.$router.push('/me');
        //     alert(res.data.msg)
        //   }else {
        //     alert("注册失败！"+res.data.msg)
        //     return
        //   }
        //   }
        // )
        // axios({
        //   method: 'post',
        //   url: 'http://127.0.0.1/api/student/register',
        //   data: {
        //     stunum: this.stunum,
        //     stupwd_1: this.stupwd_1
        //   }
        // })
          axios.post('http://127.0.0.1:5000/api/student/register',{
            stunum:this.stunum,
            stupwd_1:this.stupwd_1
          }).then(res => {
          if (res.data.code == 1) {
            this.$router.push('/me');
            alert(res.data.msg);
          } else {
            alert(res.data.msg);
            return;
          }
        })


      }
    }
  }
</script>

<style scoped>

</style>
