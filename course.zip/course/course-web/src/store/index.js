import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    Authorization: localStorage.getItem('Authorization') ? localStorage.getItem('Authorization') : ''
  },

  mutations: {
    changeLogin(state, student) {
      state.Authorization = student.Authorization;
      // console.log("store/index.js-----到这里了");
      localStorage.setItem('Authorization', student.Authorization);
    },
    delLogin(state){
      state.Authorization = ''
      localStorage.removeItem('Authorization')
    }
  }
})
