<template>
  <div>
    <div v-if="stuIsLogin">
      <h4>当前学号：{{stuinfo}}</h4>
    </div>
    <div v-else>
      <h1>资源共享课</h1>
    </div>

    <div>
      <div class="course-group">
        <div class="course-item" v-for="(course,index) in course_list" :key="index">
          <a :href="course.url_href">
            <div class="course-img">
              <img :src="course.image" alt="">
            </div>
          </a>
          <div class="course-dessc">
            <div class="course-title" style="width: 150px;white-space: nowrap; overflow:hidden;">
              <span>{{course.title}}</span></div>
            <div class="course-tch"><span>{{course.tch}}</span>&nbsp;|&nbsp;<span>{{course.school}}</span></div>
          </div>
        </div>
      </div>

    </div>
  </div>

</template>

<script>
  import axios from 'axios'

  export default {
    name: "CourseShare",
    data() {
      return {
        course_list: '',
        stuinfo: '',
        stuIsLogin:''
      }
    },
    mounted() {
      axios.get('http://127.0.0.1:5000/api/course/list').then(res => {
        // console.log(res.data);
        this.course_list = res.data
      })
      this.stuLogin()
    },
    methods: {
      stuLogin() {
        axios.get("http://127.0.0.1:5000/api/student/info").then(
          res => {
            if (res.data.code == 1) {
              this.stuIsLogin = true
              this.stuinfo = res.data.result.stunum
              // console.log(res.data.result);
            } else {
              this.stuIsLogin = false
            }
          }
        )
      }
    }
  }
</script>

<style scoped>
  .course-group {
    display: flex;
    flex-direction: row;
    justify-content: space-around;
    flex-wrap: wrap;
  }

  .course-item {
    box-shadow: 2px 2px 2px #999999;
    border: 1px #999 solid;
    margin-bottom: 3%;
  }

  .course-img {
    width: 158px;
    height: 92px;
  }

  .course-img img {
    width: 100%;
    height: 100%;
  }

  .course-dessc {
    margin: 8px 0 5px 5px;
  }

  .course-title {
    font-size: 16px;
    color: #333;
    font-weight: bold;
    text-shadow: #333333 1px 1px 1px;
  }

  .course-tch {
    margin-top: 3px;
    font-size: 12px;
    /*text-shadow: #999999 1px 1px 1px;*/
    color: #999999;
    font-weight: bold;
  }
</style>
