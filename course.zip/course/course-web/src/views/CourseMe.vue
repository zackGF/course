<template>
  <div>
    <div v-if="stuLogin">
      <h2>学号：{{stuinfo}}</h2>
      <el-button @click="LogOut">注销此账户</el-button>
    </div>
    <div v-else class="me-sign">
      <el-button-group>
        <el-button><router-link :to="{name:'StuLogin'}"><span>登录</span></router-link></el-button>
        <el-button><router-link :to="{name:'StuReg'}"><span>注册</span></router-link></el-button>
      </el-button-group>
      <div>
        <router-view></router-view>
      </div>
    </div>
  </div>

</template>

<script>
  import axios from 'axios'
  export default {
    name: "CourseMe",
    data(){
      return{
        stuLogin:false,
        stuinfo:''
      }
    },
    mounted() {
      axios.get("http://127.0.0.1:5000/api/student/info").then(
        res=>{
          if (res.data.code == 1) {
            this.stuLogin=true
            this.stuinfo=res.data.result.stunum
            // console.log(res.data.result);
          }else {
            this.stuLogin=false
          }
        }
      )
    },
    methods:{
      LogOut(){
        this.$store.commit('delLogin')
        this.$router.push('/')
      }
    }
  }
</script>

<style scoped>
  .me-sign{
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
  }
  .me-sign span{
    color: gray;
  }
</style>
