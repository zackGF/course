<template>
  <div>
    <h1>首页</h1>
  </div>
</template>

<script>
  import NavHeader from '@/components/NavHeader'
  export default {
    name: "CourseIndex",
    components:{
      NavHeader
    }
  }
</script>

<style scoped>

</style>
