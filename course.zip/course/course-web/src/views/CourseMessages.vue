<template>
  <div>
    <div v-if="stuIsLogin">
      <div style="text-align: center;margin-bottom: 20px">
        <span style="font-size: 24px;font-weight: bold">留言板</span>
      </div>
      <el-form ref="form">
        <el-form-item>
          <el-input type="text" placeholder="学号或用户名" v-model="stunum" :disabled="true"></el-input>
        </el-form-item>
        <el-form-item>
          <el-input type="textarea" placeholder="留言内容" v-model="text"></el-input>
        </el-form-item>
        <el-form-item style="text-align: center">
          <el-button type="primary" @click="onSubmit">上传评论</el-button>
        </el-form-item>
      </el-form>
    </div>
    <div v-else>
      <h2>尚未登录</h2>
    </div>

    <div class="messages-header">共 {{ messages.length }} 条留言</div>
    <div class="messages">
      <ul tansition="fade">
        <template v-for="message in messages">
          <message-item :message="message"></message-item>
        </template>
      </ul>
    </div>
  </div>
</template>

<script>
  import MessageItem from '@/components/MessageItem'
  import axios from 'axios'

  export default {
    name: "CourseMessages",
    data() {
      return {
        name: '',
        text: '',
        stuIsLogin: false,
        stunum:'',

        // 测试数据
        messages: [
          // {name: 'Jack', text: 'Awesome', created_at: '2020-01-29T11:04:52.226Z'},
          // {name: 'Tom', text: 'I like it', created_at: '2020-01-19T11:04:52.226Z'},
          // {name: 'Alex', text: 'Good job!', created_at: '2020-01-09T11:04:52.226Z'},
        ]
      }
    },
    mounted() {
      // this.onShow();
      axios.get('http://127.0.0.1:5000/api/message/list').then(res=>{
        this.messages=res.data
      });
      axios({
        method: 'get',
        url: 'http://127.0.0.1:5000/api/student/info'
      }).then(res => {
        if (res.data.code == 1) {
          this.stuIsLogin = true
          this.stunum = res.data.result.stunum
          // console.log(res.data.result.stunum);
        } else {
          this.stuIsLogin = false
        }
      })
    },
    methods: {
      onShow(){
        axios.get('http://127.0.0.1:5000/api/message/list').then(res=>{
          this.messages=res.data
        })
      },
      onSubmit() {
        if (this.stunum.length < 1 || this.text.length < 1) {
          alert("学号和留言内容为空！");
          return
        }
        axios.post("http://127.0.0.1:5000/api/message/add_msg",{
          'name':this.stunum,
          'text':this.text
        }).then(res=>{
          if (res.data.ok) {
            this.messages.unshift({
              name: this.stunum,
              text: this.text,
              created_at: new Date().toISOString()
            });
            this.text=''
          }else {
            alert(res.data.msg);
            return;
          }
        })
      }
    },
    components: {
      MessageItem
    }
  }
</script>

<style>
  .container {
    width: 650px;
    margin-top: 60px;
  }

  #app {
    margin-top: 60px;
    margin: 0 auto;
  }

  .title {
    text-align: center;
    margin-bottom: 20px;
    color: #e3e3e3;
  }

  .messages-header {
    line-height: 1;
    color: #666;
    padding: 20px 0 6px;
    border-bottom: 1px solid #eee;
    text-transform: uppercase;
    font-size: 13px;
  }

  .messages ul {
    margin: 0;
    padding: 0;
  }
</style>
